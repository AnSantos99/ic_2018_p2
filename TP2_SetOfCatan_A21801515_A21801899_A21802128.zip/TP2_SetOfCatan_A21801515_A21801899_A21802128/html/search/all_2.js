var searchData=
[
  ['desert',['desert',['../structplayer.html#a84b1de5c800206aae8c5062b75ae3f91',1,'player']]],
  ['down',['down',['../structplayer.html#aac8fc1be53dcc0753b735f20510be9d4',1,'player']]]
];
