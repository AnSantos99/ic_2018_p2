var searchData=
[
  ['left',['left',['../structplayer.html#ad8f5e19e19f12974c9713e920ec54331',1,'player']]],
  ['lumber',['lumber',['../structplayer.html#a285a827a7b7ce97466e213939d7ed77d',1,'player']]]
];
