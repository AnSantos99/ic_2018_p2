var searchData=
[
  ['right',['right',['../structplayer.html#a2f54f8b71f0d765e2b7dbd9a8b9774ff',1,'player']]]
];
