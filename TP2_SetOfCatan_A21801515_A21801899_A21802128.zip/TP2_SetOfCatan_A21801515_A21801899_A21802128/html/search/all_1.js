var searchData=
[
  ['choice',['choice',['../structplayer.html#a63bd75f20c553f0d65d7bb29b3f35696',1,'player']]],
  ['choice2',['choice2',['../structplayer.html#a0ae0ba0aaa9c114a4e8ead51d181a9c8',1,'player']]],
  ['choice3',['choice3',['../structplayer.html#a926806e71e10c7c8aa2b3649de67c09e',1,'player']]],
  ['city',['city',['../structplayer.html#aa45a22600c4168373651e7783a5d15fe',1,'player']]]
];
