var indexSectionsWithContent =
{
  0: "bcdgilprsuvw",
  1: "p",
  2: "bcdgilrsuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Variables"
};

