var searchData=
[
  ['score',['score',['../structplayer.html#aef160b7437d94056f1dc59646cd5b87d',1,'player']]],
  ['switcho',['switcho',['../structplayer.html#acb8dcc8e7ac3c76f712f605aeacfca26',1,'player']]]
];
