var searchData=
[
  ['villages',['villages',['../structplayer.html#a4381c6031a4991c45292121f26d0d1ab',1,'player']]]
];
