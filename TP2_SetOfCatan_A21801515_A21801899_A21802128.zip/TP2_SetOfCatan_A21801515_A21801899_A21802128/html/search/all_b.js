var searchData=
[
  ['wool',['wool',['../structplayer.html#a47a954a2b92a831cd4cb56b70def44d7',1,'player']]]
];
