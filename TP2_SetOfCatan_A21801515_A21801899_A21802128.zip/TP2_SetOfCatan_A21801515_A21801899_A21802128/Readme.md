# Setllers of Catan

**Ana dos Santos - a21801899**
**Ana Carvalho - a21802128**
**Diana Levay - a21801515**


# Processo
Inicialmente foi elaborado um fluxograma simples no momento da discussão e brainstorming em  formato digital.

O código foi feito na íntegra pelas alunas com consulta do site do stackoverflow para melhor entender o funcionamento dos structs com a utilização de pointers. Além disso consultamos  forums de discussões sobe o calloc e guiamo-nos nos slides dados no âmbito da cadeira de introdução à computação (2018-2019) lecionada pelo professor Pedro Arroz Correia com colaboração do professor Nuno Fachada para a incoporação do file ini.

O programa inicia dando uma mensagem de bem vinda ao user e pedindo a cada jogador para escolher onde quer coloca a sua aldeia.

O primeiro jogador rola entao o dado e comeca o jogo.

Apresenta então 7 opções, em que o jogador escolhe entre comprar mais aldeias (tem um limite de 3 no nosso jogo), tornar a sua aldeia central numa cidade, trocar cartas por cartas ou por um ponto, passar para o proximo jogador, imprimir um menu de instrucoes e sair do jogo

Foram utilizadas a biblioteca “stdio.h” para permitir o uso do standard input e output assim como as funções, “unistd.h” para recriar um “timer” que gera tensão, e para gerar um número aleatório que muda conforme o segundo em que executa, o que levou à necessidade de importar a biblioteca “time.h” para os dados, “stdlib.h” para leitura de strings no mapa a "string.h",  a "malloc.h" para alocar memoria dinamicamente.

Foi também possível aplicar conhecimentos sobre o terminal do linux e a utilizacao do github já que foi o meio usado para escrever, compilar e enviar o programa, permitindo a aprendizagem de comandos e métodos para a criação e partilha de programas em C.

Infelizmente, não fomos capazes de incorporar devidamente a leitura do ini, mas enviamos em anexo o documento ".h" com o que seria a nossa letura se tivessemos tido tempo de a completar. A pasta com os ficheiros do ini "LerMapaini.tar.xz"

### Descrição da solução:
- Arquitetura da solução
 Abrindo o programa, o código é executado e o mapa lido, de seguida aparece uma opção a perguntar onde o jogador quer inserir a aldeia. A resposta leva ao "while", que contêm várias condições "if" com as várias opções que o jogador tem. Existe um menu que é impresso que explica as opções que o jogador tem. 
Existem no total 8 opções, 
No fim de um ciclo while de um jogador, muda para outro jogador até completar novamente um ciclo while e assim sucessivamente. O jogo acaba quando um jogador atingir 6 pontos

- Fluxograma simples

- Estruturas de dados

- Algoritmos relevantes


### Manual de utilizador
- Como compilar
	o jogo encontra-se numa pasta titulada "TP2_SetOfCatan_a21801515_a21801899_a21802128"
	ao abrir o terminal tem que se invocar o ficheiro Makefile.
	Os comandos sao: gcc std=c99 -Wall -Wextra -Wpedantic -g -o file file.c

- Como jogar
	Cada jogador começa o jogo com a escolha da localização da sua aldeia. Após isso o jogador 1 começa a rodar os dados. Dependentemente da soma dos dois dados ele podera ganhar recursos das casas adjacentes com base na soma dos dados. Além disso o jogador podera interagir com varias opções do menu.
	-Option A --> Jogador pode comprar Aldeias nas casa adjacentes com um limite de compra de duas aldeias.
	-Option B --> Quando o jogador tiver recursos suficientes podera fazer um upgrade na sua aldeia para obter uma cidade.
	-Option C --> Fazer trocas de recursos ex. Jogador deseja brick. Então jogador podera trocar 4 cartas de recurso que tem para trocar no banco e 	      recebe 1 carta que desejava.
	-Option D --> 10 cartas para obter um ponto. Jogador troca 10 cartas de 1 recurso para obter 1 ponto.
	-Option E --> Passar jogada para proximo jogador.
	-Option F --> Opção que explica as regras do jogo.
	-Option X --> Sair do jogo.
	
	O jogador que chega primeiro a ter 6 pontos ganha.

### Conclusões e matéria aprendida
Em conclusão, este trabalho permitiu a consolidação e aplicação da matéria lecionada nas aulas. Para este projeto, usou-se o linux e o seu terminal com o editor nano para criar o código, permitindo uma familiarizacao com este, foi tambem possivel aplicar os conhecimentos sobre structs, alocacao de memoria, pointers e ciclos ao longo do development deste jogo.

### Referências
O código foi realizado pelas alunas integrantes do grupo tendo havido trocas de ideias com o aluno João Moreira e usado referencias de sites como o stack overflow, sendo que sempre foram realizadas otimizacoes com base no nosso codigo.

Para concluir, o trabalho permitiu a consolidação e aplicação direta de conhecimentos adquiridos nas aulas como o uso de bibliotecas, a criação e utilização de variáveis e funções, o random, controlo de fluxo associado a ciclos, operadores e aplicação correta da indentação e comentacao de codigo.





