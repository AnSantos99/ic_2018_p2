/*----------------SETTLERS OF CATAN GAME----------------*/

/* Exercicio final computação
Ana dos Santos - a21801899
Ana Sofia Carvalho - a21802128
Diana Ascencao Levay - a21801515 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>

// defining each player
typedef struct player{
	char name[20]; // distinguish player 1 and 2
	int switcho; // switch between players in loop
	int score; // show player score
	int choice; //first village
	int choice2; //second Village
	int choice3; //third village
	int grain; //start inventory
	int iron;
	int desert;
	int wool;
	int brick;
	int lumber; //end inventory
	int up; // start adjacent villages
	int down;
	int left;
	int right; // end adjacent villages
	int city; // verify if village is upgraded
	int villages; // how many villages the player has 
}player;


// define two players and one (x) that allows switching between them
struct player playerx, player1, player2; 

typedef struct mapa{
	char linha1[100];
	char linha2[100];
	char linha3[100];
	char linha4[100];
	char linha5[100];
	char linha6[100];
	char linha7[100];
	char linha8[100];
	char linha9[100];
	char linha10[100];
	char linha11[100];
	char linha12[100];
	char linha13[100];
	char linha14[100];
	char linha15[100];
	char linha16[100];
	
}mapa;

struct mapa mapa1;


// function that verifies the villages adjacent to the player and gives them the resources if the dice matches a number
void adjacent_villages(struct player *plyr,int* dice1, int* dice2, int* sum){
	int up = (*plyr).up; // verify the village up from the chosen one
	int down = (*plyr).down; // verify the village down from the chosen one
	int left = (*plyr).left; // verify the village left from the chosen one
	int right = (*plyr).right; // verify the village right from the chosen one

	for (int i = 0; i<=15; i++){ //Cicle that gains +1 resource depending on which adjacent map it is and if player has city he will gain 2 more
		if ((up == 0 || left == 0) && i == 0){
			if (*sum == 4){

				if ((*plyr).city == 0) {
					(*plyr).brick += 1;
				}
				
				else {
					(*plyr).brick += 2;
				} 
			}
			if (*sum == 11){
				if ((*plyr).city == 0) {
					(*plyr).lumber += 1;
					}
				else {
					(*plyr).lumber += 2;
					}	
			}
		}

		if ((up == 1 || left == 1 || right == 1) && i == 1){
			if (*sum == 6){
				if ((*plyr).city == 0){
					(*plyr).iron += 1;
				}
				else{
					(*plyr).iron += 2;
				}
			}
			if (*sum == 12){
				if ((*plyr).city == 0){ 
					(*plyr).wool += 1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if(*sum == 11){
				if ((*plyr).city == 0){
					(*plyr).lumber +=1;
				}
				else{
					(*plyr).lumber += 2;
				}
			}
		}

		if ((up == 2 || left == 2 || right == 2) && i == 2){
			if (*sum == 5){
				if ((*plyr).city == 0){
					(*plyr).brick += 1;
				}
				else{
					(*plyr).brick += 2;
				}
			}
			if (*sum == 9){
				if ((*plyr).city == 0){
					(*plyr).grain += 1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
			if(*sum == 12){
				if ((*plyr).city == 0){
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
		}
		
		if ((up == 3 || right == 3) && i == 3){
			if (*sum == 10){
				if ((*plyr).city == 0){
					(*plyr).wool += 1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if(*sum == 9){
				if ((*plyr).city == 0){
					(*plyr).grain += 1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
		}

		if ((up == 4 || down == 4 || left == 4) && i == 4){
			if (*sum == 4){
				if ((*plyr).city == 0){
					(*plyr).brick += 1;
				}
				else{
					(*plyr).brick += 2;
				}
			}
			if(*sum == 3){
				if ((*plyr).city == 0){
					(*plyr).grain +=1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
		}

		if ((up == 5 || left == 5 || right == 5 || down == 5) && i == 5){
			if (*sum == 6){
				if ((*plyr).city == 0){
					(*plyr).iron += 1;
				}
				else{
					(*plyr).iron += 2;
				}
			}
			if (*sum == 3){
				if ((*plyr).city == 0){ 
					(*plyr).lumber +=1;
				}
				else{
					(*plyr).lumber += 2;
				}
			}
			if (*sum == 10){
				if ((*plyr).city == 0){ 
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
		}
		
		if ((up == 6 || left == 6 || right == 6 || down == 6) && i == 6){
			if (*sum == 5){
				if ((*plyr).city == 0){
					(*plyr).brick += 1;
				}
				else{
					(*plyr).brick += 2;
				}
			}
			if (*sum == 11){
				if ((*plyr).city == 0){ 
					(*plyr).grain +=1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
			if (*sum == 10){
				if ((*plyr).city == 0){  
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
		}
		
		if ((up == 7 || right == 7 || down == 7) && i == 7){
			if (*sum == 10){
				if ((*plyr).city == 0){ 
					(*plyr).wool += 1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if (*sum == 4){
				if ((*plyr).city == 0){ 
					(*plyr).lumber +=1;
				}
				else{
					(*plyr).lumber += 2;
				}
			}
		}

		if ((up == 8 || down == 8 || left == 8) && i == 8){
			if (*sum == 3){
				if ((*plyr).city == 0){ 
					(*plyr).grain += 1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
			if (*sum == 8){
				if ((*plyr).city == 0){ 
					(*plyr).brick +=1;
				}
				else {
					(*plyr).brick += 2;
				}
			}
		}


		if ((up == 9 || left == 9 || right == 9 || down == 9) && i == 9){
			if (*sum == 3){
				if ((*plyr).city == 0){
					(*plyr).lumber += 1;
				}
			}
			if (*sum == 10){
				if ((*plyr).city == 0){  
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if (*sum == 9){
				if ((*plyr).city == 0){ 
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
		}

		if ((up == 10 || left == 10 || right == 10 || down == 10) && i == 10){
			if (*sum == 11){
				if ((*plyr).city == 0){ 
					(*plyr).grain += 1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
			if (*sum == 10){
				if ((*plyr).city == 0){ 
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if (*sum == 9){
				if ((*plyr).city == 0){ 
					(*plyr).wool +=1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
		}

		if ((up == 11 || right == 11 || down == 11) && i == 11){
			if (*sum == 4){
				if ((*plyr).city == 0){
					(*plyr).lumber += 1;
				}
				else{
					(*plyr).lumber += 2;
				}
			}
			if (*sum == 3){
				if ((*plyr).city == 0){ 
					(*plyr).iron +=1;
				}
				else{
					(*plyr).iron += 2;
				}
			}
		}

		if ((down == 12 || left == 12) && i == 12){
			if (*sum == 8){
				if ((*plyr).city == 0){
					(*plyr).brick += 1;
				}
				else{
					(*plyr).brick += 2;
				}
			}
			if (*sum == 5){
				if ((*plyr).city == 0){
					(*plyr).iron +=1;
				}
				else{
					(*plyr).iron += 2;
				}
			}
		}

		if ((down == 13 || left == 13) || right == 13 && i == 13){
			if (*sum == 10){
				if ((*plyr).city == 0){ 
					(*plyr).wool += 1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if (*sum == 2){
				if ((*plyr).city == 0){ 
					(*plyr).grain +=1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
			if (*sum == 5){
				if ((*plyr).city == 0){
					(*plyr).iron +=1;
				}
				else{
					(*plyr).iron += 2;
				}
			}
		}

		if ((down == 14 || left == 14) || right == 14 && i == 14){
			if (*sum == 10){
				if ((*plyr).city == 0){
					(*plyr).wool += 1;
				}
				else{
					(*plyr).wool += 2;
				}
			}
			if (*sum == 6){
				if ((*plyr).city == 0){
					(*plyr).lumber +=1;
				}
				else{
					(*plyr).lumber += 2;
				}
			}
			if (*sum == 2){
				if ((*plyr).city == 0){
					(*plyr).grain += 1;
				}
				else{
					(*plyr).grain += 2;
				}
			}
		}
		
		if ((down == 15 || right == 15) && i == 15){
			if (*sum == 3){
				if ((*plyr).city == 0){
					(*plyr).iron += 1;
				}
				else{
					(*plyr).iron += 2;
				}
			}
			if (*sum == 6){
				if ((*plyr).city == 0){ 
					(*plyr).lumber += 1;
				}
				else{
					(*plyr).lumber += 2;
				}
			}
		}
	}
}

// function that displays the chosen users inventory
void showInventory(struct player *plyr) {
	printf("your village: %d \nyour second village: %d \nyour third village: %d \n\n current inventory: \n wool(W): %d \n brick(B): %d \n lumber(L): %d \n grain(G): %d \n iron(I): %d \n\n score: %d \n\n",(*plyr).choice,(*plyr).choice2,(*plyr).choice3, (*plyr).wool, (*plyr).brick, (*plyr).lumber, (*plyr).grain, (*plyr).iron, (*plyr).score;
}


//funcion that rolls the dice randomly
void rollDice (struct player *plyr, int* dice1, int* dice2, int* sum) {
	
	while(1) {
		printf("Please roll the dice with d");
		int roll = getchar();
		getchar();
		if (roll == 'd' || roll == 'D') {
			srand((int) time (NULL));
			*dice1 = 1 + (rand()%7);
			sleep(1);
			*dice2 = 1 + (rand()%7);
			*sum = *dice1 + *dice2;
			printf("dice:\n%d + %d = %d \n\n ", *dice1, *dice2, *sum);
			break;
		}	
		else {
			printf("Please press d!\n");
			getchar();
			continue;
		}
	}
}

//funcion that asks each player to place their village
void village_choice (struct player *plyr) {
	printf("Choose a number to place your village in, %s\n",(*plyr).name);
	int villageNumb;
	int choice = scanf(" %d",&villageNumb);
	getchar();
	
	printf("%d",villageNumb);

	(*plyr).up = villageNumb - 4 ; //determines the adjacent village up to the chosen one
	(*plyr).down = villageNumb + 4; //determines the adjacent village down to the chosen one
	(*plyr).left = villageNumb - 1; //determines the adjacent village left to the chosen one
	(*plyr).right = villageNumb + 1; //determines the adjacent village right to the chosen one

	// determine what village was chosen and give its resources to the player
	if (villageNumb == 0){
		(*plyr).choice = 0;
		(*plyr).brick += 4; (*plyr).lumber += 11;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 1){
		(*plyr).choice = 1;
		(*plyr).iron += 6; (*plyr).wool += 12; (*plyr).lumber +=11;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 2){
		(*plyr).choice = 2;
		(*plyr).brick += 5; (*plyr).grain += 9; (*plyr).wool += 12;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 3){
		(*plyr).choice = 3;
		(*plyr).wool += 10; (*plyr).grain += 9;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 4){
		(*plyr).choice = 4;
		(*plyr).brick += 4; (*plyr).grain += 3;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 5){
		(*plyr).choice = 5;
		(*plyr).iron += 6; (*plyr).lumber += 3; (*plyr).wool += 10; 
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 6){
		(*plyr).choice = 6;
		(*plyr).brick += 5; (*plyr).grain += 11; (*plyr).wool += 10; 
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 7){
		(*plyr).choice = 7;
		(*plyr).lumber += 4; (*plyr).wool += 10; 
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 8){
		(*plyr).choice = 8;
		(*plyr).grain += 3; (*plyr).brick += 8; 
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 9){
		(*plyr).choice = 9;
		(*plyr).lumber += 3; (*plyr).wool += 10; (*plyr).wool += 9; 
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 10){
		(*plyr).choice = 10;
		(*plyr).grain += 11; (*plyr).wool += 9; (*plyr).wool += 10; 
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 11){
		(*plyr).choice = 11;
		(*plyr).lumber += 4; (*plyr).iron += 3;
		printf("Chosen village: #%d\n", villageNumb);
	}

	else if (villageNumb == 12){
		(*plyr).choice = 12;
		(*plyr).brick += 8; (*plyr).iron += 5;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 13){
		(*plyr).choice = 13;
		(*plyr).wool += 10; (*plyr).grain += 2; (*plyr).iron += 5;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 14){
		(*plyr).choice = 14;
		(*plyr).wool += 10; (*plyr).lumber += 6; (*plyr).grain += 2;
		printf("Chosen village: #%d\n", villageNumb);
	}
	
	else if (villageNumb == 15){
		(*plyr).choice = 15;
		(*plyr).iron += 3; (*plyr).lumber += 6;
		printf("Chosen village: #%d\n", villageNumb);
	}
} 	

//function to exchange 4 cards for 1
void cardExchange (struct player *plyr) {

	printf("Choose the letter of the resource to trade (you will lose 4 cards)\n");
	int card1 = getchar();
	getchar();

	printf("Choose the letter of the resource to obtain (you will get 1 card)\n");
	int card2 = getchar();
	getchar();

	if (card1 == 'W' || card1 == 'w' && (*plyr).wool >= 4) {
		(*plyr).wool -= 4;
	}
	else if (card1 == 'B' || card1 == 'b' && (*plyr).brick >= 4){
		(*plyr).brick -=4;
	}
	else if (card1 == 'L' || card1 == 'l' && (*plyr).lumber >= 4){
		(*plyr).lumber -=4;	
	}
	else if (card1 == 'I' || card1 == 'i' && (*plyr).iron >= 4){
		(*plyr).iron -=4;
	}
	else if (card1 == 'G' || card1 == 'g' && (*plyr).grain >= 4){
		(*plyr).grain -=4;
	} 


	if (card2 == 'W' || card2 == 'w'){
		(*plyr).wool +=1;		
	}
	else if (card2 == 'B' || card2 == 'b'){
		(*plyr).brick += 1;
	}
	else if (card2 == 'L' || card2 == 'l'){
		(*plyr).lumber +=1;
	}
	else if (card2 == 'I' || card2 == 'i'){
		(*plyr).iron +=1;
	}
	else if (card2 == 'G' || card2 == 'g'){
		(*plyr).grain +=1;
	}

	else {
	printf("\n Try again!\n");
	}
	  
}


//function to exchange 10 cards for 1 point
void pointExchange (struct player *plyr) {
	printf("Choose the letter of the resource to trade (you will lose 4 cards)\n");
	int card = getchar();
	getchar();

	if (card == 'W' || card == 'w' && (*plyr).wool >= 10) {
		(*plyr).wool -= 10;
		(*plyr).score += 1;
	}
	if (card == 'B' || card == 'b' && (*plyr).brick >= 4) {
		(*plyr).brick -= 10;
		(*plyr).score += 1;
	}
	if (card == 'L' || card == 'l' && (*plyr).brick >= 4) {
		(*plyr).lumber -= 10;
		(*plyr).score += 1;
	}
	if (card == 'G' || card == 'g' && (*plyr).grain >= 4) {
		(*plyr).grain -= 10;
		(*plyr).score += 1;
	}
	if (card == 'I' || card == 'i' && (*plyr).iron >= 4) {
		(*plyr).iron -= 10;
		(*plyr).score += 1;
	}	 
	else{
		printf("\nTry again!\n");
	}			      
}
struct mapa mapa1 = {"\n|      N:D      |      N:D      |      N:D      |      N:D      |",
		     "\n|      S:B(4)   |      S:I(6)   |      S:B(5)   |    S:W(10)    |",
		     "\n|      E:L(11)  |      E:W(12)  |      E:G(9)   |      E:D      |",
		     "\n|      W:D      |      W:W(10)  |      W:D      |      W:D      |",
		     "\n|      N:B(4)   |      N:I(16)  |      N:I(5)   |      N:W(10)  |",
		     "\n|      S:G(3)   |      S:L(3)   |      S:G(11)  |      S:L(4)   |",
		     "\n|      E:D      |      E:W(9)   |      E:D      |      E:D      |",
		     "\n|      W:D      |      W:D      |      W:W(9)   |      W:D      |",
		     "\n|      N:G(3)   |      N:L(3)   |      N:G(11)  |      N:L(4)   |",
		     "\n|      S:B(8)   |      S:W(10)  |      S:W(10)  |      S:I(3)   |",
		     "\n|      E:D      |      E:W(9)   |      E:D      |      E:D      |",
		     "\n|      W:D      |      W:D      |      W:(9)    |      W:D      |",
		     "\n|      N:B(8)   |      N:W(10)  |      N:W(10)  |      N:I(3)   |",
		     "\n|      S:D      |      S:D      |      S:D      |      S:D      |",
		     "\n|      E:I(5)   |      E:G(2)   |      E:L(6)   |      E:D      |",
		     "\n|      W:D      |      W:I(5)   |      W:G(2)   |      W:L(6)   |",};
// begin the program 
int main() {

	
	// loops to print the map
	int **d;
	int u = 0;
	int s = 0;
	
	for(int i = 0; i<4; i++) {
	    d[i] = (int *)calloc(4,sizeof(int));
	}

	// for each of the lines
	for(int i = 0; i<4; i++){
		for(int j = 0; j<4; j++){
			d[i][j] = i+j;
			s += d[i][j];
			if (u < 10 && u != 3 && u != 7)  {
				printf("+-----#[%d]------", u);
				u++;
			}

			else if (u == 3 || u == 7 )  {
				printf("+------#[%d]-----+", u);
				u++;
			}

			else if (u >= 10 && u != 11 && u != 15){
				printf("+-----#[%d]-----", u);
				u++;
			}

			else if (u == 11 || u == 15 )  {
				printf("+-----#[%d]-----+", u);
				u++;
			}	
		}
			// for each resource in each line
			if (u == 4) {
			printf("%s %s %s %s",mapa1.linha1,mapa1.linha2,mapa1.linha3,mapa1.linha4);
			}
			if (u == 8) {
			printf("%s %s %s %s",mapa1.linha5,mapa1.linha6,mapa1.linha7,mapa1.linha8);
			}
			if (u == 12) {
			printf("%s %s %s %s",mapa1.linha9,mapa1.linha10,mapa1.linha11,mapa1.linha12);
			}
			if (u == 16) {
			printf("%s %s %s %s",mapa1.linha13,mapa1.linha14,mapa1.linha15,mapa1.linha16);
			
			}
			
		printf("\n");		
	}
	
	
	// print the last line
	d = (int **)calloc(4, sizeof(int));
	printf("+---------------+---------------+--------------+----------------+\n");

	//define both players and the empty struct that allows switching between them in the loop
	struct player player1 = {"player 1",0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
	struct player player2 = {"player 2",1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
	struct player playerx = player1;
	

	//define and begin the playing loop  
	char play = 'y';
	int welcome = 0; // welcome loop to only welcome players once
	int playo = 0; // for the welcome loop 
	int dice1, dice2; // initiating the two dice
	int sum; // the sum of the two dice for the adjacent verification

	do{   
		// for only printing the welcome message and village choice once
		if (welcome <= 0){
			printf("*** Welcome to Settlers of Catan! ***\n\n");
			village_choice(&player1); 
			village_choice(&player2);
			playerx = player1;
			welcome += 1; // so it doesnt ask again
			continue;
		}

		// for the second player to roll the first time
		if (playo <= 0) {
			if (playerx.switcho == 0) {
				rollDice(&playerx, &dice1, &dice2, &sum);
				adjacent_villages(&playerx, &dice1, &dice2, &sum);
				playo += 1;
				continue;
			}
		}
		
		// verify if player has reached 6 points and won
		if (playerx.score >= 6) {
			printf("You reached 6 points first! You win! \n\n");
			break; 
			play = 'n';
		} 
		
		
		// print inventory + score
		showInventory(&playerx);


		//print main option menu and ask for input
		printf("Main menu: \n\n"
		"[A] Buy an adjacent village \n"
		"[B] Transform village into city! (double resources) \n"
		"[C] Bank exchange - 4 units for 1 unit \n"
		"[D] Bank exchange - 10 units for one point \n"
		"[E] Pass to next player \n"
		"[F] Help\n"
		"[X] Exit Game\n\n");
		printf("Please select option:\n");

		int option = getchar();
		getchar();

		// Option A - Buy a village in adjacent position 
		if (option =='A'|| option == 'a'){ 
			if (playerx.brick >= 1 && playerx.lumber >= 1 && playerx.grain >=1 && playerx.wool >= 1) {
				playerx.brick -= 1;
				playerx.lumber -= 1;
				playerx.grain -= 1;
				playerx.wool -= 1;
				int v; // for assigning the input to the placing of the village
				printf("Where do you wanna build your village?");
				int villageNumb;
				int *answer = scanf(" %d",&v); 
				getchar();
				sleep(1);
					
					// if the player chooses the second village 
					if (playerx.villages == 0) {
						if (v == playerx.up){
							playerx.choice2 = v; 
							printf("New village is:%d", playerx.choice2);	
						}
						else if (v == playerx.down){
							playerx.choice2 = v;
							printf("New village is:%d", playerx.choice2);	
						}
						else if (v == playerx.left){
							playerx.choice2 = v;
							printf("New village is:%d", playerx.choice2);	
						}
						else if (v == playerx.right){
							playerx.choice2 = v;
							printf("New village is:%d", playerx.choice2);	
						}
					}

					// verifies if the player already has more than one village
					else {
						if (v == playerx.up){
							playerx.choice3 = v;
							printf("New village is:%d", playerx.choice3);	
						}
						else if (v == playerx.down){
							playerx.choice3 = v;
							printf("New village is:%d", playerx.choice3);	
						}
						else if (v == playerx.left){
							playerx.choice3 = v;
							printf("New village is:%d", playerx.choice3);	
						}
						else if (v == playerx.right){
							playerx.choice3 = v;
							printf("New village is:%d", playerx.choice3);	
						}	
					}
					
				continue;

				}
			
			
			else{
				printf("You have not enough resources to buy a village.");
				continue;
			}
		}  

		// Option B - Transform center village into city 
		else if (option == 'B' || option == 'b'){
			if (playerx.grain >= 2 && playerx.iron >= 3){
				printf("Your city is born!");			
				playerx.city = 1;
				playerx.grain -= 2;
				playerx.iron -= 3;
				continue;
			}
			else{
				printf("You have not enough resources to upgrade to a city!");
			}
		}  

		// Option C - Bank exchange (4 cards of a chosen resource for 1 card of another chosen resource)
		else if (option == 'C' || option == 'c'){
			cardExchange (&playerx);
			continue;
		}

		// Option D - Bank exchange (10 cards of a chosen resource for 1 point)
		else if (option == 'D' || option == 'd'){
			pointExchange(&playerx);
			continue;
		} 

		// Option E - pass turn to other player
		else if (option == 'E' || option == 'e') {
			// verifies whom the current player is and switches to the other
			if (playerx.switcho == 0) {
				player1 = playerx;
				playerx = player2;
				rollDice(&playerx, &dice1, &dice2, &sum);
				adjacent_villages(&playerx, &dice1, &dice2, &sum);
			}
			else if (playerx.switcho == 1) {
				player2 = playerx;
				playerx = player1;
				rollDice(&playerx, &dice1, &dice2, &sum);
				adjacent_villages(&playerx, &dice1, &dice2, &sum);
			}
			continue;
		} 

		// Option F - display instructions / help 
		else if (option == 'F' || option == 'f'){
			printf("\n**\n"
			"This is settlers of Catan \n\n"
			"in order to win, you must obtain 6 points before your opponent!\n\n"
			"you started off by choosing a village placement, that village will be the base of your game\n\n"
			"if you wish to get another village (adjacent to your main one), press [A] on the menu! \nMake sure you have these cards though: B + L + G + W\n\n"
			"however, you can expand your village into a city by pressing [B]! \nYou'll need this combination: G + G + I + I + I \n\n"
			"You can exchange 4 cards of a unit for a single cart of a unit of your choosing with [C]\n\n"
			"By clicking [D], you can exchange 10 unit cards for one point. \n\n"
			"Pressing [E] allows you to pass your turn to the other player\n"
			"Please enjoy the game!\n\n"
			"**\n\n");
			continue;
		} 

		// finish - game over 
		else if (option == 'X' || option == 'x'){ 
			break;
		} 

		else {
		printf("Invalid answer! Try again \n"); 
		getchar(); 
			continue;
		} 

		printf("\n");
	}

	while (play == 'y' || play == 'Y');
	return 0; 
}
